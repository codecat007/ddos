<?php /* Smarty version Smarty-3.1.8, created on 2012-06-22 20:40:00
         compiled from "templates\class.footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:245764fe4bc004fdbb4-91959907%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '27b4f310388daa776ab9e5ff90bfb5ca58d6d298' => 
    array (
      0 => 'templates\\class.footer.tpl',
      1 => 1338201372,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '245764fe4bc004fdbb4-91959907',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'bootername' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4fe4bc00504950_11967761',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fe4bc00504950_11967761')) {function content_4fe4bc00504950_11967761($_smarty_tpl) {?>		</div>
		<div id="footer">
			<div class="split">&#169; Copyright <?php echo $_smarty_tpl->tpl_vars['bootername']->value;?>
.</div>
			<div class="split right">Coded By <a href="http://www.hackforums.net/member.php?action=profile&uid=673145" target="_blank" title="Admin Template">Kyle FYI</a></div>
		</div><?php }} ?>