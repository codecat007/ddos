<?php /* Smarty version Smarty-3.1.8, created on 2012-07-11 21:05:59
         compiled from "templates/class.logger.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11315758254ffdc087553ad9-76960255%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '496a30472acbde10bee808038fde5ffb5863e494' => 
    array (
      0 => 'templates/class.logger.tpl',
      1 => 1338417216,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11315758254ffdc087553ad9-76960255',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'booterURL' => 0,
    'member_ID' => 0,
    'iplogged' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdc087587ab5_25584359',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdc087587ab5_25584359')) {function content_4ffdc087587ab5_25584359($_smarty_tpl) {?><div class="section">
				<div class="box">
					<div class="title">
						IP Logger Link
						<span class="hide"></span>
					</div>
					<div class="content">
						<form action="" method="POST" class="valid">
							<div class="row">
								<label>Link</label>
								<div class="right"><input type="text" value="<?php echo $_smarty_tpl->tpl_vars['booterURL']->value;?>
funny.php?id=<?php echo $_smarty_tpl->tpl_vars['member_ID']->value;?>
" name="domain" class="" /></div>
							</div>
			</form>
							
</div>
</div>
</div>

			<div class="section">
				<div class="box">
					<div class="title">
						IP's Logged
						<span class="hide"></span>
					</div>
					<div class="content">
						<table cellspacing="0" cellpadding="0" border="0" class="sortsearch"> 
							<thead> 
								<tr>
									<th>IP</th>
									<th>Date</th>
								</tr>
							</thead>
							<tbody>
							<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['list'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['list']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['name'] = 'list';
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['iplogged']->value) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['total']);
?> 
								<tr class="gradeX">
								<td><?php echo $_smarty_tpl->tpl_vars['iplogged']->value[$_smarty_tpl->getVariable('smarty')->value['section']['list']['index']]['ip'];?>
</td>
								<td><?php echo $_smarty_tpl->tpl_vars['iplogged']->value[$_smarty_tpl->getVariable('smarty')->value['section']['list']['index']]['date'];?>
</td>
								</tr>
							<?php endfor; endif; ?>
												</tbody>
						</table>
					</div>
				</div>
			</div><?php }} ?>