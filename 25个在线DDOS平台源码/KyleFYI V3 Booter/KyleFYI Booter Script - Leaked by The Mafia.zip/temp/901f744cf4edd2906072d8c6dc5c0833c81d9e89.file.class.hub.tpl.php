<?php /* Smarty version Smarty-3.1.8, created on 2012-07-15 19:12:06
         compiled from "templates/class.hub.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7481765024ffdbf3e8a7980-79558337%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '901f744cf4edd2906072d8c6dc5c0833c81d9e89' => 
    array (
      0 => 'templates/class.hub.tpl',
      1 => 1342368665,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7481765024ffdbf3e8a7980-79558337',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbf3e8cef44_82995676',
  'variables' => 
  array (
    'attack' => 0,
    'domain' => 0,
    'maxboot' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbf3e8cef44_82995676')) {function content_4ffdbf3e8cef44_82995676($_smarty_tpl) {?><div class="section">
				<div class="box">
					<div class="title">
						Host 2 IP/Skype Resolver
						<span class="hide"></span>
					</div>
					<div class="content">
						<form action="" method="POST" class="valid">
							<div class="row">
								<label>Domain</label>
						    		<div class="right"><input type="text" value="" name="domain"



 class="" /></div>				</div>

														<div class="row">
								<label></label>
								<div class="right">
									<button type="submit"><span>Grab IP</span></button>
								</div>
							</div>
			</form>
							
</div>
</div>
</div>


<div class="section">
				<div class="box">
					<div class="title">
						Boot
						<span class="hide"></span>
					</div>
					<div class="content">
					<marquee behavior="scroll" direction="left" scrollamount="15"><?php echo $_smarty_tpl->tpl_vars['attack']->value;?>
</marquee>
						<form action="" method="POST" class="valid">
							<div class="row">
								<label>Type</label>
								<div class="right">
									<select name="type" class="">
										<option value="UDP">UDP</option>
									</select>
								</div>
							</div>
							<div class="row">
								<label>Host</label>
								<div class="right"><input type="text" value="<?php echo $_smarty_tpl->tpl_vars['domain']->value;?>
" name="host" class="" /></div>
							</div>
					<div class="row">
								<label>Port</label>
								<div class="right"><input type="text" value="" name="port" class="" /></div>
							</div>
							<div class="row">
									<label>Time</label>
									<div class="right">
										<div class="slider single-slide">
										
											Time: <input type="text" style="width: 100px;" class="amount" readonly="readonly" name="time" value="" />
											<div class="slide" value="30" max="<?php echo $_smarty_tpl->tpl_vars['maxboot']->value;?>
" min="10"></div>
										</div>
									</div>
								</div>
													<div class="row">
									<label>Power</label>
									<div class="right">
										<div class="slider single-slide">
											Power: <input type="text" class="amount" readonly="readonly" name="power" value="" />%
											<div class="slide" value="50" max="100" min="10"></div>
										</div>
									</div>
								</div>
							<div class="row">
								<label></label>
								<div class="right">
									<button type="submit"><span>Start Attack</span></button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div><?php }} ?>