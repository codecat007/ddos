<?php /* Smarty version Smarty-3.1.8, created on 2012-07-11 21:31:33
         compiled from "templates/class.don.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5279695384ffdc68542a0c0-09796036%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '621e3b0de77080385cdcc41041bbf751513252e5' => 
    array (
      0 => 'templates/class.don.tpl',
      1 => 1338415938,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5279695384ffdc68542a0c0-09796036',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'check' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdc68544ea74_24768354',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdc68544ea74_24768354')) {function content_4ffdc68544ea74_24768354($_smarty_tpl) {?><div class="section">
				<div class="box">
					<div class="title">
						Down or Not?
						<span class="hide"></span>
					</div>
					<div class="content">
						<form action="" method="POST" class="valid">
						<?php echo $_smarty_tpl->tpl_vars['check']->value;?>

							<div class="row">
								<label>IP Address</label>
								<div class="right"><input type="text" value="" name="ip" class="" /></div>
							</div>
														<div class="row">
								<label></label>
								<div class="right">
									<button type="submit"><span>Check</span></button>
								</div>
							</div>
			</form>
							
</div>
</div>
</div><?php }} ?>