<?php /* Smarty version Smarty-3.1.8, created on 2012-07-12 04:14:52
         compiled from "templates/class.reseller.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8377118864ffe250c7afba6-95570234%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '31d768c10b92dab8cf16d376f11152d6b565d50b' => 
    array (
      0 => 'templates/class.reseller.tpl',
      1 => 1340102608,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8377118864ffe250c7afba6-95570234',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'check' => 0,
    'iplogged' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffe250c88a111_03670383',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffe250c88a111_03670383')) {function content_4ffe250c88a111_03670383($_smarty_tpl) {?><div class="section">
				<div class="box">
					<div class="title">
						Add User
						<span class="hide"></span>
					</div>
					<div class="content">
						<form action="" method="POST" class="valid">
						<?php echo $_smarty_tpl->tpl_vars['check']->value;?>

							<div class="row">
								<label>Max Boot Time</label>
								<div class="right"><input type="text" value="" name="max" class="" /></div>
							</div>
							<div class="row">
								<label>Expiry</label>
								<div class="right"><input type="text" value="" name="expiry" class="" /></div>
							</div>
														<div class="row">
								<label></label>
								<div class="right">
									<button type="submit"><span>Add Key</span></button>
								</div>
							</div>
			</form>
							
</div>
</div>
</div>	

<div class="section">
				<div class="box">
					<div class="title">
						Users
						<span class="hide"></span>
					</div>
					<div class="content">
						<table cellspacing="0" cellpadding="0" border="0" class="sortsearch"> 
							<thead> 
								<tr>
									<th>Users</th>
									<th>Max Boot</th>
									<th>Attacks</th>
									<th>Type</th>
									<th>Key</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['list'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['list']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['name'] = 'list';
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['iplogged']->value) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['list']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['list']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['list']['total']);
?> 
								<tr class="gradeX">
								<td><?php echo $_smarty_tpl->tpl_vars['iplogged']->value[$_smarty_tpl->getVariable('smarty')->value['section']['list']['index']]['login'];?>
</td>
								<td><?php echo $_smarty_tpl->tpl_vars['iplogged']->value[$_smarty_tpl->getVariable('smarty')->value['section']['list']['index']]['max'];?>
</td>
								<td><?php echo $_smarty_tpl->tpl_vars['iplogged']->value[$_smarty_tpl->getVariable('smarty')->value['section']['list']['index']]['attacks'];?>
</td>
								<td><?php echo $_smarty_tpl->tpl_vars['iplogged']->value[$_smarty_tpl->getVariable('smarty')->value['section']['list']['index']]['type'];?>
</td>
								<td><?php echo $_smarty_tpl->tpl_vars['iplogged']->value[$_smarty_tpl->getVariable('smarty')->value['section']['list']['index']]['key'];?>
</td>
								<td><a href="?remove=<?php echo $_smarty_tpl->tpl_vars['iplogged']->value[$_smarty_tpl->getVariable('smarty')->value['section']['list']['index']]['login'];?>
">Remove</a> - <a href="?ban=<?php echo $_smarty_tpl->tpl_vars['iplogged']->value[$_smarty_tpl->getVariable('smarty')->value['section']['list']['index']]['login'];?>
">Ban</a>
								</tr>
							<?php endfor; endif; ?>
												</tbody>
						</table>
					</div>
				</div>
			</div><?php }} ?>