<?php /* Smarty version Smarty-3.1.8, created on 2012-07-15 07:58:33
         compiled from "../templates/class.footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19768505544ffdbe635791f0-86443124%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '88276c8863a6c3d4e2257a188778b1ca38e22045' => 
    array (
      0 => '../templates/class.footer.tpl',
      1 => 1342328241,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19768505544ffdbe635791f0-86443124',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbe6357c128_15621768',
  'variables' => 
  array (
    'bootername' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbe6357c128_15621768')) {function content_4ffdbe6357c128_15621768($_smarty_tpl) {?>		</div>
		<div id="footer">
			<div class="split">&#169; Copyright <?php echo $_smarty_tpl->tpl_vars['bootername']->value;?>
.</div>
			<div class="split right"><a href="http://www.tacticalstresser.net/skype.php">Skype Resolver!!!</a></a></div>
		</div><?php }} ?>