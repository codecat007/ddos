<?php /* Smarty version Smarty-3.1.8, created on 2012-07-11 21:57:44
         compiled from "templates/class.header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20521592804ffdbe5383c214-54331763%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '444ac935bbaaf448d7c8a42722b48f98f56630ed' => 
    array (
      0 => 'templates/class.header.tpl',
      1 => 1342033060,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20521592804ffdbe5383c214-54331763',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbe538e5e42_16883473',
  'variables' => 
  array (
    'bootername' => 0,
    'template' => 0,
    'username' => 0,
    'type' => 0,
    'maxboot' => 0,
    'total_users' => 0,
    'timeleft' => 0,
    'shells' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbe538e5e42_16883473')) {function content_4ffdbe538e5e42_16883473($_smarty_tpl) {?>			
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" /> 
	<title><?php echo $_smarty_tpl->tpl_vars['bootername']->value;?>
</title>
	
	<meta name="apple-mobile-web-app-capable" content="no" />
	<meta name="apple-mobile-web-app-status-bar-style" content="black" />
	<meta name="viewport" content="width=device-width,initial-scale=0.69,user-scalable=yes,maximum-scale=1.00" />



		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/style.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/forms.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/forms-btn.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/menu.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/style_text.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/datatables.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/fullcalendar.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/pirebox.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/modalwindow.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/statics.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/tabs-toggle.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/system-message.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/tooltip.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/wizard.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/wysiwyg.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/wysiwyg.modal.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/wysiwyg-editor.css" /> 
		<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/css/handheld.css" /> 
	
	
	
	<!--[if lte IE 8]>
		<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/excanvas.min.js"></script>
	<![endif]-->
	
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.backgroundPosition.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.placeholder.min.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.ui.1.8.17.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.ui.select.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.ui.spinner.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/superfish.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/supersubs.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.datatables.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/fullcalendar.min.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.smartwizard-2.0.min.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/pirobox.extended.min.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.tipsy.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.elastic.source.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.jBreadCrumb.1.1.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.customInput.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.metadata.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.filestyle.mini.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.filter.input.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.flot.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.flot.pie.min.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.flot.resize.min.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.graphtable-0.2.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/jquery.wysiwyg.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/controls/wysiwyg.image.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/controls/wysiwyg.link.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/controls/wysiwyg.table.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/plugins/wysiwyg.rmFormat.js"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['template']->value;?>
/js/costum.js"></script>
	
</head>

<body>

<div id="wrapper">
	<div id="container">
	
		<div class="hide-btn top tip-s" original-title="Close sidebar"></div>
		<div class="hide-btn center tip-s" original-title="Close sidebar"></div>
		<div class="hide-btn bottom tip-s" original-title="Close sidebar"></div>
		
		<div id="top">
			<h1 id="logo"><a href="./"></a></h1>
			<div id="labels">
				<ul>
					<li><a href="index.php" class="user"><span class="bar">Welcome <?php echo $_smarty_tpl->tpl_vars['username']->value;?>
</span></a></li>
					<li><a href="profile.php" class="settings"></a></li>
					<li><a href="logout.php" class="logout"></a></li>
				</ul>
			</div>
			<div id="menu">
				<ul> 
					<li><a href="index.php">Dashboard</a></li> 
					<li><a href="hub.php">Boot</a> </li> 
					<li><a href="cfr.php">CloudFlare Resolver</a></li>
					<li><a href="don.php">Down or not?</a></li>
						<li><a href="ip_logger.php">IP Logger</a></li>
						<li>
						<a href="#">Friends/Enemys</a>
						<ul> 
							<li><a href="friends.php">Friends</a></li>
							<li><a href="enemys.php">Enemys</a></li>
						</ul>
					</li>
					<li><a href="attacks.php">My Attacks</a></li>
					<?php if ($_smarty_tpl->tpl_vars['type']->value=='reseller'){?>
						<li><a href="reseller.php">Reseller</a></li>
					<?php }?>
				</ul>
			</div>
		</div>
		
		<div id="left">
		<?php if ($_smarty_tpl->tpl_vars['type']->value=='admin'){?>
			<div class="box submenu">
				<div class="content">
					<ul>
						<li><a href="admin/users.php">List Users</a></li>
						<li><a href="admin/add.php">Add Users</a></li>
						<li><a href="admin/logs.php">View Logs</a></li>
						<li><a href="admin/news.php">News Manger</a></li>
						<li><a href="admin/blacklist.php">BlackList</a></li>
						<li><a href="admin/shells.php">Add Servers</a></li>
					</ul>
				</div>
			</div>
			<?php }?>
			<div class="box statics">
				<div class="content">
					<ul>
						<li><h2>Statistics</h2></li>
						<li>Your Max Boot Time <div class="info red"><span><?php echo $_smarty_tpl->tpl_vars['maxboot']->value;?>
</span></div></li>
						<li>Total Users <div class="info green"><span><?php echo $_smarty_tpl->tpl_vars['total_users']->value;?>
</span></div></li>
						<li>Expiry Data <div class="info red"><span><?php echo $_smarty_tpl->tpl_vars['timeleft']->value;?>
</span></div></li>
						<li>Servers <div class="info blue"><span><?php echo $_smarty_tpl->tpl_vars['shells']->value;?>
</span></div></li>
					</ul>
				</div>
			</div>
		</div>
		
				<div id="right">
		<?php }} ?>