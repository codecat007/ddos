<?php /* Smarty version Smarty-3.1.8, created on 2012-07-11 20:59:25
         compiled from "../templates/class.add.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1071769454ffdbefdab5812-97763008%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eeb6168441d79c19ed1176d080be83d54ee88830' => 
    array (
      0 => '../templates/class.add.tpl',
      1 => 1340101688,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1071769454ffdbefdab5812-97763008',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'check' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbefdad8216_68928710',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbefdad8216_68928710')) {function content_4ffdbefdad8216_68928710($_smarty_tpl) {?><div class="section">
				<div class="box">
					<div class="title">
						Add User
						<span class="hide"></span>
					</div>
					<div class="content">
						<form action="" method="POST" class="valid">
						<?php echo $_smarty_tpl->tpl_vars['check']->value;?>

							<div class="row">
								<label>Max Boot Time</label>
								<div class="right"><input type="text" value="" name="max" class="" /></div>
							</div>
							<div class="row">
								<label>Expiry</label>
								<div class="right"><input type="text" value="" name="expiry" class="" /></div>
							</div>
							<div class="row">
								<label>Type</label>
								<div class="right">
									<select name="type" class="">
										<option value="user">User</option>
										<option value="reseller">Reseller</option>
										<option value="admin">Admin</option>
									</select>
								</div>
							</div>
														<div class="row">
								<label></label>
								<div class="right">
									<button type="submit"><span>Add Key</span></button>
								</div>
							</div>
			</form>
							
</div>
</div>
</div>	<?php }} ?>