<?php /* Smarty version Smarty-3.1.8, created on 2012-07-11 22:20:52
         compiled from "templates/class.register.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14589854184ffdbfd29dad19-82108833%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2379da2f9fd15a831efd301b546a604e1d721e81' => 
    array (
      0 => 'templates/class.register.tpl',
      1 => 1342034449,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14589854184ffdbfd29dad19-82108833',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbfd2a00c36_51757930',
  'variables' => 
  array (
    'bootername' => 0,
    'done' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbfd2a00c36_51757930')) {function content_4ffdbfd2a00c36_51757930($_smarty_tpl) {?>			
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" /> 
	<title><?php echo $_smarty_tpl->tpl_vars['bootername']->value;?>
: Login</title>

	<meta name="apple-mobile-web-app-capable" content="no" />
	<meta name="apple-mobile-web-app-status-bar-style" content="black" />
	<meta name="viewport" content="width=device-width,initial-scale=0.69,user-scalable=yes,maximum-scale=1.00" />
<link rel="stylesheet" type="text/css" href="style/reset.css" /> 
	
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/style.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/forms.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/forms-btn.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/menu.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/style_text.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/datatables.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/fullcalendar.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/pirebox.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/modalwindow.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/statics.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/tabs-toggle.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/system-message.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/tooltip.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wizard.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg.modal.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg-editor.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/handheld.css" /> 
	
	
	
	<!--[if lte IE 8]>
		<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/excanvas.min.js"></script>
	<![endif]-->
	
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.backgroundPosition.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.placeholder.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.1.8.17.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.select.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.spinner.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/superfish.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/supersubs.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.datatables.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/fullcalendar.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.smartwizard-2.0.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/pirobox.extended.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.tipsy.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.elastic.source.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.jBreadCrumb.1.1.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.customInput.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.metadata.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.filestyle.mini.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.filter.input.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.pie.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.resize.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.graphtable-0.2.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.wysiwyg.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.image.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.link.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.table.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/plugins/wysiwyg.rmFormat.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/costum.js"></script>
	
</head>

<body>

<div id="wrapper" class="login">
	
	<div class="box">
		<div class="title">
			Please Register
			<span class="hide"></span>
		</div>
		<div class="content">
		<?php echo $_smarty_tpl->tpl_vars['done']->value;?>

			<form action="" method="POST">
				<div class="row">
					<label>Username</label>
					<div class="right"><input type="text" name="username" value="" /></div>
				</div>
				<div class="row">
					<label>Password</label>
					<div class="right"><input type="password" name="password" value="" /></div>
				</div>
				<div class="row">
					<label>Personal License Key</label>
					<div class="right"><input type="password" name="key" value="" /></div>
				</div>
				<div class="row">
					<div class="right">
						<button type="submit"><span>Register</span></button>
					</div>
				</div>
			</form>
		</div>
	</div>
	
</div>
</script>

</body>

</html> <?php }} ?>