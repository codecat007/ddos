<?php /* Smarty version Smarty-3.1.8, created on 2012-07-11 20:47:01
         compiled from "templates/class.install.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14636146284ffdbc15c50813-58473546%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '291db2504c9e27b06cd5430e783fcf43bdb2e10a' => 
    array (
      0 => 'templates/class.install.tpl',
      1 => 1338913444,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14636146284ffdbc15c50813-58473546',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'bootername' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbc15c96cf7_50569016',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbc15c96cf7_50569016')) {function content_4ffdbc15c96cf7_50569016($_smarty_tpl) {?>			
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" /> 
	<title><?php echo $_smarty_tpl->tpl_vars['bootername']->value;?>
: Login</title>

	<meta name="apple-mobile-web-app-capable" content="no" />
	<meta name="apple-mobile-web-app-status-bar-style" content="black" />
	<meta name="viewport" content="width=device-width,initial-scale=0.69,user-scalable=yes,maximum-scale=1.00" />
<link rel="stylesheet" type="text/css" href="style/reset.css" /> 
	
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/style.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/forms.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/forms-btn.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/menu.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/style_text.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/datatables.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/fullcalendar.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/pirebox.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/modalwindow.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/statics.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/tabs-toggle.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/system-message.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/tooltip.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wizard.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg.modal.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg-editor.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/handheld.css" /> 
	
	
	
	<!--[if lte IE 8]>
		<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/excanvas.min.js"></script>
	<![endif]-->
	
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.backgroundPosition.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.placeholder.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.1.8.17.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.select.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.spinner.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/superfish.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/supersubs.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.datatables.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/fullcalendar.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.smartwizard-2.0.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/pirobox.extended.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.tipsy.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.elastic.source.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.jBreadCrumb.1.1.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.customInput.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.metadata.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.filestyle.mini.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.filter.input.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.pie.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.resize.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.graphtable-0.2.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.wysiwyg.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.image.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.link.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.table.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/plugins/wysiwyg.rmFormat.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/costum.js"></script>
	
</head>

<body>

<div id="wrapper" class="login">
	
	<div class="box">
		<div class="title">
			Install
			<span class="hide"></span>
		</div>
		<div class="content">
			<form action="" method="POST">
			First import the SQL DB File and then run the install file!
				<div class="row">
					<label>Admin Username</label>
					<div class="right"><input type="text" name="username" value="" /></div>
				</div>
				<div class="row">
					<label>Admin Password</label>
					<div class="right"><input type="password" name="password" value="" /></div>
				</div>
				<div class="row">
					<label>Host</label>
					<div class="right"><input type="text" name="host" value="" /></div>
				</div>
				<div class="row">
					<label>DB USER</label>
					<div class="right"><input type="text" name="user" value="" /></div>
				</div>
				<div class="row">
					<label>DB Name</label>
					<div class="right"><input type="text" name="name" value="" /></div>
				</div>
				<div class="row">
					<label>DB Password</label>
					<div class="right"><input type="password" name="dbpassword" value="" /></div>
				</div>
				<div class="row">
					<label>Booter Name</label>
					<div class="right"><input type="text" name="bname" value="" /></div>
				</div>
				<div class="row">
					<label>Booter URL</label>
					<div class="right"><input type="text" name="URL" value="" /></div>
				</div>
				<div class="row">
					<div class="right">
						<button type="submit"><span>Install</span></button>
					</div>
				</div>
			</form>
		</div>
	</div>
	
</div>
</script>

</body>

</html> <?php }} ?>