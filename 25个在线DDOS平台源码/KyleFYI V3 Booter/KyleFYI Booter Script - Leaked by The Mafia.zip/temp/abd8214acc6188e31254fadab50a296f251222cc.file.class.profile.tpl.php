<?php /* Smarty version Smarty-3.1.8, created on 2012-07-11 20:58:51
         compiled from "templates/class.profile.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11010553854ffdbedba2c882-47874283%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'abd8214acc6188e31254fadab50a296f251222cc' => 
    array (
      0 => 'templates/class.profile.tpl',
      1 => 1340042618,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11010553854ffdbedba2c882-47874283',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'password' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbedba4ee76_11226266',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbedba4ee76_11226266')) {function content_4ffdbedba4ee76_11226266($_smarty_tpl) {?><div class="section">
				<div class="box">
					<div class="title">
						Change Password
						<span class="hide"></span>
					</div>
					<?php echo $_smarty_tpl->tpl_vars['password']->value;?>

					<div class="content">
						<form action="" method="POST" class="valid">
							<div class="row">
								<label>New password</label>
								<div class="right"><input type="text" value="" name="password" class="" /></div>
							</div>
							<div class="row">
								<label>Repeat password</label>
								<div class="right"><input type="text" value="" name="repassword" class="" /></div>
							</div>
														<div class="row">
								<label></label>
								<div class="right">
									<button type="submit"><span>Change Password</span></button>
								</div>
							</div>
			</form>
							
</div>
</div>
</div>
<?php }} ?>