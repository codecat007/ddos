<?php /* Smarty version Smarty-3.1.8, created on 2012-06-19 14:35:14
         compiled from "../templates\class.footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:296244fe07202f20ce5-53749782%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b9bc972aabfeec0e7abf575510f13d1bea3e4c26' => 
    array (
      0 => '../templates\\class.footer.tpl',
      1 => 1338201372,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '296244fe07202f20ce5-53749782',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'bootername' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4fe07202f271a8_70404235',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fe07202f271a8_70404235')) {function content_4fe07202f271a8_70404235($_smarty_tpl) {?>		</div>
		<div id="footer">
			<div class="split">&#169; Copyright <?php echo $_smarty_tpl->tpl_vars['bootername']->value;?>
.</div>
			<div class="split right">Coded By <a href="http://www.hackforums.net/member.php?action=profile&uid=673145" target="_blank" title="Admin Template">Kyle FYI</a></div>
		</div><?php }} ?>