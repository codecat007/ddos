<?php /* Smarty version Smarty-3.1.8, created on 2012-07-11 20:59:05
         compiled from "../templates/class.news.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5059273274ffdbee99316d8-29657580%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7788f37f7bb6b1e3a12b0eaf63fff08bc415a0e8' => 
    array (
      0 => '../templates/class.news.tpl',
      1 => 1338557148,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5059273274ffdbee99316d8-29657580',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'check' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbee99542a0_18595847',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbee99542a0_18595847')) {function content_4ffdbee99542a0_18595847($_smarty_tpl) {?><div class="section">
				<div class="box">
					<div class="title">
						Add News
						<span class="hide"></span>
					</div>
					<div class="content">
						<form action="" method="POST" class="valid">
						<?php echo $_smarty_tpl->tpl_vars['check']->value;?>

							<div class="row">
								<label>Subject</label>
								<div class="right"><input type="text" value="" name="subject" class="" /></div>
							</div>
							<div class="row">
								<label>Message</label>
								<div class="right"><textarea rows="" name="message" cols="" style="height : 100px;"></textarea></div>
							</div>
														<div class="row">
								<label></label>
								<div class="right">
									<button type="submit"><span>Add News</span></button>
								</div>
							</div>
			</form>
							
</div>
</div>
</div><?php }} ?>