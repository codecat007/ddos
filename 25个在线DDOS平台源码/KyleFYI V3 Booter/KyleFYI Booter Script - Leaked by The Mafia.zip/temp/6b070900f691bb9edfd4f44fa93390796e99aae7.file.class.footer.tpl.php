<?php /* Smarty version Smarty-3.1.8, created on 2012-07-15 07:57:25
         compiled from "templates/class.footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5017818384ffdbe539051b0-25481176%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6b070900f691bb9edfd4f44fa93390796e99aae7' => 
    array (
      0 => 'templates/class.footer.tpl',
      1 => 1342328241,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5017818384ffdbe539051b0-25481176',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbe539080e5_57811825',
  'variables' => 
  array (
    'bootername' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbe539080e5_57811825')) {function content_4ffdbe539080e5_57811825($_smarty_tpl) {?>		</div>
		<div id="footer">
			<div class="split">&#169; Copyright <?php echo $_smarty_tpl->tpl_vars['bootername']->value;?>
.</div>
			<div class="split right"><a href="http://www.tacticalstresser.net/skype.php">Skype Resolver!!!</a></a></div>
		</div><?php }} ?>