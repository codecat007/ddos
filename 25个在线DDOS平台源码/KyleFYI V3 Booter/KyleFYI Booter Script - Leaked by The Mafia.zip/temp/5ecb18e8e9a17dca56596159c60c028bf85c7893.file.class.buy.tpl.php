<?php /* Smarty version Smarty-3.1.8, created on 2012-07-15 00:47:38
         compiled from "templates/class.buy.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15563554244fff5ae83da251-48616555%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5ecb18e8e9a17dca56596159c60c028bf85c7893' => 
    array (
      0 => 'templates/class.buy.tpl',
      1 => 1342302048,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15563554244fff5ae83da251-48616555',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4fff5ae86c20d1_31868640',
  'variables' => 
  array (
    'bootername' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fff5ae86c20d1_31868640')) {function content_4fff5ae86c20d1_31868640($_smarty_tpl) {?>			
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" /> 
	<title><?php echo $_smarty_tpl->tpl_vars['bootername']->value;?>
: Login</title>

	<meta name="apple-mobile-web-app-capable" content="no" />
	<meta name="apple-mobile-web-app-status-bar-style" content="black" />
	<meta name="viewport" content="width=device-width,initial-scale=0.69,user-scalable=yes,maximum-scale=1.00" />
<link rel="stylesheet" type="text/css" href="style/reset.css" /> 
	
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/style.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/forms.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/forms-btn.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/menu.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/style_text.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/datatables.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/fullcalendar.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/pirebox.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/modalwindow.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/statics.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/tabs-toggle.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/system-message.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/tooltip.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wizard.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg.modal.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg-editor.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/handheld.css" /> 
	
	
	
	<!--[if lte IE 8]>
		<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/excanvas.min.js"></script>
	<![endif]-->
	
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.backgroundPosition.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.placeholder.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.1.8.17.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.select.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.spinner.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/superfish.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/supersubs.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.datatables.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/fullcalendar.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.smartwizard-2.0.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/pirobox.extended.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.tipsy.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.elastic.source.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.jBreadCrumb.1.1.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.customInput.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.metadata.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.filestyle.mini.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.filter.input.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.pie.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.resize.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.graphtable-0.2.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.wysiwyg.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.image.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.link.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.table.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/plugins/wysiwyg.rmFormat.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/costum.js"></script>
	
</head>

<body>

<div id="wrapper" class="login">
	
	<div class="box">
		<div class="title">
			Please Select the package
			<span class="hide"></span>
			
		</div>
		<div class="content">

1 month 300 second boot
 <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="6AAEFBXDMJTZJ">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
 1 month 500 second boot
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="9G33TQAVCURUJ">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
 1 month 1000 boot
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="LS84NNP2LRZJN">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
lifetime 300
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="HZ9XWRN95S5JU">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
lifetime 500
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="KXZCJRXDPP62Y">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
lifetime 1000
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="YF99DMHU7WBWQ">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
			
		</div>
	</div>
	
</div>
</script>

</body>

</html> <?php }} ?>