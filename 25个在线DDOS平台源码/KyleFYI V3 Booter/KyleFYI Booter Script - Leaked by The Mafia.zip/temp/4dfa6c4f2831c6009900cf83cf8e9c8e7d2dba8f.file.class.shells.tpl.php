<?php /* Smarty version Smarty-3.1.8, created on 2012-07-11 23:17:54
         compiled from "../templates/class.shells.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19397093064ffdbe7e7a19a1-29118705%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4dfa6c4f2831c6009900cf83cf8e9c8e7d2dba8f' => 
    array (
      0 => '../templates/class.shells.tpl',
      1 => 1342037869,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19397093064ffdbe7e7a19a1-29118705',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbe7e7c0222_08712577',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbe7e7c0222_08712577')) {function content_4ffdbe7e7c0222_08712577($_smarty_tpl) {?><div class="section">
				<div class="box">
					<div class="title">
						Add Shells
						<span class="hide"></span>
					</div>
					<div class="content">
						<form action="" method="POST" class="valid">
						
							<div class="row">
								<label>Shell URL</label>
								<div class="right"><input type="text" value="" name="shell" class="" /></div>
							</div>
														<div class="row">
								<label></label>
								<div class="right">
									<button type="submit"><span>Add Shell</span></button>
								</div>
							</div>
			</form>
							
</div>
</div>
</div>	

<div class="section">
				<div class="box">
					<div class="title">
						Add Shells
						<span class="hide"></span>
					</div>
					<div class="content">
						<form action="" method="POST" class="valid">
					
							<div class="row">
								<textarea name="url" cols="80" rows="10"></textarea>
							</div>
														<div class="row">
								<label></label>
								<div class="right">
									<button type="submit" name="Submit"><span>Add Shells</span></button>
								</div>
							</div>
			</form>
							
</div>
</div>
</div>	

<?php }} ?>