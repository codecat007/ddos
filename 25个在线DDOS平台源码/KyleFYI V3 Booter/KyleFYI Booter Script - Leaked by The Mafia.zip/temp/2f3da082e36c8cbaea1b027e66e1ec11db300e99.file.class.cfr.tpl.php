<?php /* Smarty version Smarty-3.1.8, created on 2012-07-11 21:02:33
         compiled from "templates/class.cfr.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16297816194ffdbfb9b77d43-32062396%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2f3da082e36c8cbaea1b027e66e1ec11db300e99' => 
    array (
      0 => 'templates/class.cfr.tpl',
      1 => 1338415474,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16297816194ffdbfb9b77d43-32062396',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'ips' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbfb9b99df2_75372119',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbfb9b99df2_75372119')) {function content_4ffdbfb9b99df2_75372119($_smarty_tpl) {?><div class="section">
				<div class="box">
					<div class="title">
						Cloudflare Resolver
						<span class="hide"></span>
					</div>
					<div class="content">
						<form action="" method="POST" class="valid">
						<?php echo $_smarty_tpl->tpl_vars['ips']->value;?>

							<div class="row">
								<label>Domain</label>
								<div class="right"><input type="text" value="" name="domain" class="" /></div>
							</div>
														<div class="row">
								<label></label>
								<div class="right">
									<button type="submit"><span>Grab IP</span></button>
								</div>
							</div>
			</form>
							
</div>
</div>
</div><?php }} ?>