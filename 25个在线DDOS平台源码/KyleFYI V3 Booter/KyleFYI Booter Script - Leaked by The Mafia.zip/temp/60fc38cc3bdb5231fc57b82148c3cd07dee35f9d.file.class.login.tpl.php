<?php /* Smarty version Smarty-3.1.8, created on 2012-07-13 02:58:28
         compiled from "templates/class.login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17002957094ffdbd5c9476b0-24028912%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '60fc38cc3bdb5231fc57b82148c3cd07dee35f9d' => 
    array (
      0 => 'templates/class.login.tpl',
      1 => 1342137505,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17002957094ffdbd5c9476b0-24028912',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4ffdbd5c97aa94_39153515',
  'variables' => 
  array (
    'bootername' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4ffdbd5c97aa94_39153515')) {function content_4ffdbd5c97aa94_39153515($_smarty_tpl) {?>			
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" /> 
	<title><?php echo $_smarty_tpl->tpl_vars['bootername']->value;?>
: Login</title>

	<meta name="apple-mobile-web-app-capable" content="no" />
	<meta name="apple-mobile-web-app-status-bar-style" content="black" />
	<meta name="viewport" content="width=device-width,initial-scale=0.69,user-scalable=yes,maximum-scale=1.00" />
<link rel="stylesheet" type="text/css" href="style/reset.css" /> 
	
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/style.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/forms.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/forms-btn.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/menu.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/style_text.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/datatables.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/fullcalendar.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/pirebox.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/modalwindow.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/statics.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/tabs-toggle.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/system-message.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/tooltip.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wizard.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg.modal.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/wysiwyg-editor.css" /> 
		<link rel="stylesheet" type="text/css" href="http://dreamwire.nl/themes/Mustache/v1.2/Fixed/css/handheld.css" /> 
	
	
	
	<!--[if lte IE 8]>
		<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/excanvas.min.js"></script>
	<![endif]-->
	
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.backgroundPosition.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.placeholder.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.1.8.17.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.select.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.ui.spinner.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/superfish.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/supersubs.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.datatables.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/fullcalendar.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.smartwizard-2.0.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/pirobox.extended.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.tipsy.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.elastic.source.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.jBreadCrumb.1.1.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.customInput.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.metadata.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.filestyle.mini.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.filter.input.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.pie.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.flot.resize.min.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.graphtable-0.2.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/jquery.wysiwyg.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.image.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.link.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/controls/wysiwyg.table.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/plugins/wysiwyg.rmFormat.js"></script>
	<script type="text/javascript" src="http://www.dreamwire.nl/themes/Mustache/v1.2/Fixed/js/costum.js"></script>
	
</head>

<body>

<div id="wrapper" class="login">
	
	<div class="box">
		<div class="title">
			Please login
			<span class="hide"></span>
		</div>
		<div class="content">
		<?php if ($_smarty_tpl->tpl_vars['action']->value=='Invalid'){?>
			<div class="message inner red">
				<span><b>Error</b>: Your login details were incorrect.</span>
			</div>
		<?php }elseif($_smarty_tpl->tpl_vars['action']->value=='logout'){?>
			<div class="message inner green">
				<span><b>Succes</b>: You have logged out!</span>
			</div>
		<?php }elseif($_smarty_tpl->tpl_vars['action']->value=='na'){?>
			<div class="message inner red">
			<span><b>Error</b>: Something went wrong there, please try again.</span>
			</div>
		<?php }else{ ?>
			<div class="message inner red">
				<span><b>Important</b>: If Registering, you must have your Personal License Key present.</span>
			</div>
		<?php }?>
			<form action="login-exec.php" method="POST">
				<div class="row">
					<label>Username</label>
					<div class="right"><input type="text" name="login" value="" /></div>
				</div>
				<div class="row">
					<label>Password</label>
					<div class="right"><input type="password" name="password" value="" /></div>
				</div>
				<div class="row">
					<div class="right">
						<button type="submit"><span>Login</span></button>
						<a href="register.php"><button><span>Register</span></button></a>
                                                <div class="split right">Want to buy? <a href="http://www.tacticalstresser.net/buy.php" target="_blank" title="Buy">Click Here!</a></div>
		</div>

					</div>
				</div>
			</form>
		</div>
	</div>
	
</div>
</script>

</body>

</html> <?php }} ?>