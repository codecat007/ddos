<?php
define("DB_HOST", "localhost"); 
define("DB_USER", "");
define("DB_PASSWORD", "");
define("DB_DATABASE", "");
$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
mysql_select_db(DB_DATABASE);
$bootername = "";
$booterURL = "";
?>