<?PHP
	require_once("include/config.php");
	require('libs/Smarty.class.php');
	$smarty = new Smarty;
	$smarty->template_dir = 'templates';
	$smarty->compile_dir = 'temp';

	$smarty->assign("bootername", $bootername);
	$smarty->display("class.buy.tpl");
?>