<?php

$username = $_POST['username'];

switch($_GET['action']){
	case 'submit':
		echo file_get_contents("http://www.coleak.com/skype.php?name=".$username."&key=vypor");
	break;
}
?>
<form action="skype.php?action=submit" method="post"> 
username: <input type="text" name="username" />
<input type="submit" value="Get Ip" />