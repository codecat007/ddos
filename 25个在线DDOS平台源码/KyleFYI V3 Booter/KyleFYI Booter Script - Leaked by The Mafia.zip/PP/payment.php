<?php

require_once "../include/config.php";

// read the post from PayPal system and add 'cmd'
$req = 'cmd=_notify-validate';

foreach ($_POST as $key => $value) {
$value = urlencode(stripslashes($value));
$req .= "&$key=$value";
}

// post back to PayPal system to validate
$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);

// assign posted variables to local variables
$item_name = $_POST['item_name'];
$item_number = $_POST['item_number'];
$payment_status = $_POST['payment_status'];
$payment_amount = $_POST['mc_gross'];
$payment_currency = $_POST['mc_currency'];
$txn_id = $_POST['txn_id'];
$receiver_email = $_POST['receiver_email'];
$payer_email = strtolower(trim($_POST['payer_email']));

if (!$fp) {
// HTTP ERROR
} else {
fputs ($fp, $header . $req);
while (!feof($fp)) {
$res = fgets ($fp, 1024);
if (strcmp ($res, "VERIFIED") == 0) {

if ($payment_status == "Completed") {
	$string = genRandomString()."-".genRandomString()."-".genRandomString()."-".genRandomString()."-".genRandomString();
	$string = strtoupper($string);
if ($item_number == 1) {
	$query = mysql_query("INSERT INTO `keys` (`key`, `month`, `max`, `type`) VALUES ('".$string."', '30', '300', 'member');");
}elseif($item_number == 2){
	$query = mysql_query("INSERT INTO `keys` (`key`, `month`, `max`, `type`) VALUES ('".$string."', '30', '500', 'member');");
}elseif($item_number == 3){
	$query = mysql_query("INSERT INTO `keys` (`key`, `month`, `max`, `type`) VALUES ('".$string."', '30', '1000', 'member');");
}elseif($item_number == 4){
	$query = mysql_query("INSERT INTO `keys` (`key`, `month`, `max`, `type`) VALUES ('".$string."', 'lifetime', '300', 'member');");
}elseif($item_number == 5){
	$query = mysql_query("INSERT INTO `keys` (`key`, `month`, `max`, `type`) VALUES ('".$string."', 'lifetime', '500', 'member');");
}elseif($item_number == 6){
	$query = mysql_query("INSERT INTO `keys` (`key`, `month`, `max`, `type`) VALUES ('".$string."', 'lifetime', '1000', 'member');");
}
mail($payer_email, 'Booter Key', "Thanks for buying Booter! \n Your key is: ". $string."\n go to http://booter.com/register.php to register your account!");
}else{
mail($payer_email, 'Booter Error', "There was a error with the system, if you have been charged contact support. If not then please try again.");
}


}
else if (strcmp ($res, "INVALID") == 0) {
// log for manual investigation
//$update = mysql_query("UPDATE `users` banned = 1 WHERE email = '".$payer_email."' LIMIT 1");
}
}
fclose ($fp);
}

	function genRandomString() {
    $length = 5;
    $characters = "0123456789abcdefghijklmnopqrstuvwxyz";
    $string = ""; 
	$p = 0;
    for ($p = 0; $p < $length; $p++) {
        $string .= $characters[mt_rand(0, strlen($characters))];
    }
    return $string;
}



?>