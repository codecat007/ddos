<?php
include('auth.php');
include("./inc/config.php");
require_once("./JSON.php");
$sql = "SELECT * FROM `lst_bots` WHERE 1;";  
$res = mysql_query($sql);
$nbrows = mysql_num_rows($res);
$intervall = time() - ($setminutes * 60);
if($nbrows>0) {
    while($rec = mysql_fetch_array($res)) {
        if ($rec['lasttime'] >= $intervall)
        {
            $isonline = "1";
        }
        else
        { 
            $isonline = "0";
        }
        $rec2 = array("ID" => $rec['ID'], "UID"=> $rec['UID'],"installtime"=>$rec['installtime'],"version"=>$rec['version'],"country"=> $rec['country'],"online" => $isonline);
        $arr[] = $rec2;
    }
    $jsonresult = json_encode($arr);
    echo '{"results":'.$jsonresult.', "total":"'.$nbrows.'"}';
} else {
    echo '({"total":"0", "results":""})';
}
die("");
?>