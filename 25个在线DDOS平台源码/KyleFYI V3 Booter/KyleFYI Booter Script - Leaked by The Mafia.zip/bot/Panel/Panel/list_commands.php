<?php
include('auth.php');
include("./inc/config.php");
require_once("./JSON.php");
$sql = "SELECT * FROM `lst_commands` WHERE 1;";  
$res = mysql_query($sql);
$nbrows = mysql_num_rows($res);
if($nbrows>0) {
    while($rec = mysql_fetch_array($res)) {
        $zahl = (int)$rec['max'];
        $zahl2 = (int)$rec['done'];
        if ($zahl != 0)
        {
            $percentage = $zahl2 / $zahl;
        }
        else
        {
            $percentage = 1;
        }
        $rec2 = array("0" => "", "ID" => $rec['ID'], "1" => "", "command"=> $rec['command'],"2"=>"","parameters"=>$rec['parameters'],"3"=>"","max"=>$rec['max'],"4"=>"","done"=>$percentage);
        $arr[] = $rec2;
    }
    $jsonresult = json_encode($arr);
    echo '{"results":'.$jsonresult.', "total":"'.$nbrows.'"}';
} else {
    echo '({"total":"0", "results":""})';
}
die("");
?>