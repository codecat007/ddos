<?php
	include('auth.php');
	include("./inc/config.php");
    $valid_chars_regex = '.A-Z0-9_ !@#$%^&()+={}\[\]\',~`-';	
    $MAX_FILENAME_LENGTH = 260;
    $upload_name = 'ufile';
    if (!isset($_FILES[$upload_name])) {
        HandleError('No upload found in \$_FILES for ' . $upload_name);
    } else if (!isset($_FILES[$upload_name]["tmp_name"][0]) || !@is_uploaded_file($_FILES[$upload_name]["tmp_name"][0])) {
        HandleError('Upload failed is_uploaded_file test.');
    } else if (!isset($_FILES[$upload_name]['name'])) {
        HandleError('File has no name.');
    }
    $file_name = preg_replace('/[^'.$valid_chars_regex.']|\.+$/i', "", basename($_FILES[$upload_name]['tmp_name'][0]));
	if (strlen($file_name) == 0 || strlen($file_name) > $MAX_FILENAME_LENGTH) {
		HandleError('Invalid file name');
	}
    if (!@move_uploaded_file($_FILES['ufile']['tmp_name'][0],'uploads/server.exe')) {
		HandleError("File could not be saved.");
	}
	$str_md5 = md5_file('uploads/server.exe');
	if (!$str_md5){
		HandleError("Couldnt obtain md5 of the file, please reupload binary!");
	}
	$sql = "UPDATE `lst_settings` SET `value` = '".$str_md5."' WHERE `ID` = '1';";
    mysql_query($sql);
	die('File uploaded!');

function HandleError($message) {
	die('Error occured: '.$message);
}
?>
