<?php
	include('auth.php');
	include("./inc/config.php");
	$filename = "uploads/server.exe";
	if (file_exists($filename)){
		if (unlink($filename)){
			$sql = "UPDATE `lst_settings` SET `value` = '0' WHERE `ID` = '1';";
			mysql_query($sql);
			die("Binary deleted");
		}
		else{
			die("Couldnt delete binary!");
		}
	}
	else{
		die("There is no binary to delete!");
	}
?>
