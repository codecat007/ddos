<?php
include('auth.php');
include("./inc/config.php");
require_once("./JSON.php");
$today_day = date("j");
$today_month = date("n");
$today_year = date("Y");
$timestamp_today = mktime(0,0,0,$today_month,$today_day,$today_year);

//next 6 days
for ($i = 6; $i >= 1; $i--) {
    $tempday_day = ($timestamp_today - ($i * 86400));
    $tempday_day2 = $tempday_day + 86400;
    $sql = "SELECT * FROM `lst_bots` WHERE (`installtime_int` >= '".$tempday_day."') AND (`installtime_int` < '".$tempday_day2."');";
    $res = mysql_query($sql);
    $nbrows = mysql_num_rows($res);
    $rec2 = array("day" => date('d.n.Y', $tempday_day), "number"=> $nbrows);
    $arr[] = $rec2;
}

//today
$sql = "SELECT * FROM `lst_bots` WHERE (`installtime_int` >= '".$timestamp_today."');";
$res = mysql_query($sql);
$nbrows = mysql_num_rows($res);
$rec2 = array("day" => date('d.n.Y', $timestamp_today), "number"=> $nbrows);
$arr[] = $rec2;

$jsonresult = json_encode($arr);
echo '{"results":'.$jsonresult.', "total":"7"}';
die("");
?>