<?php
$admin_user = "admin";
$admin_pass = "admin";
$setminutes = 2;
$mysql_server = "localhost";
$mysql_user = "tactical_um";
$mysql_pw = "7&9y0g{]gM8}";
$mysql_db = "tactical_bra";
$panel_ver = "0.2.0";
$bot_ver = "1.1.1";
$link = mysql_connect($mysql_server, $mysql_user, $mysql_pw);
mysql_select_db($mysql_db, $link );
?>