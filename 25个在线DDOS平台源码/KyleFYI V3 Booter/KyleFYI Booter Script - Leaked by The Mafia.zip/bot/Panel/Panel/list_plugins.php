<?php
$dir = "plugins";
$myDirectory = opendir($dir);
while($entryName = readdir($myDirectory)) {
    if (substr($entryName, 0, 1) != ".")
    {
		if (filetype($dir.'/'.$entryName) == "dir")
        {
            $dirArr = array("name"=>$entryName,"icon"=>$dir.'/'.$entryName.'/icon.png');
            $arrPlugins[] = $dirArr;
        }
	}
}
closedir($myDirectory);
sort($arrPlugins);

$jsonresult = json_encode($arrPlugins);
$indexCount	= count($arrPlugins);
echo '{"results":'.$jsonresult.', "total":"'.$indexCount.'"}';

?>