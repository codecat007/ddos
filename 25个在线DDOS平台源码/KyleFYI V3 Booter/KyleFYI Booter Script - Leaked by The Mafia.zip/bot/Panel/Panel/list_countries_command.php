<?php
include('auth.php');
include("./inc/config.php");
require_once("./JSON.php");
$sql = "SELECT * FROM `lst_countries` WHERE 1;";  
$res = mysql_query($sql);
$nbrows = mysql_num_rows($res);
$intervall = time() - ($setminutes * 60);
if($nbrows>0) {
    while($rec = mysql_fetch_array($res)) {
        $arr[] = $rec;
    }
    $rec = array("0"=>"6","ID"=>"","1"=>"","countryname"=>"All Countries","2"=>"TOTAL","countrycode"=>"ALL","3"=>"5","totalbots"=>"","online"=>"");
    $arr[] = $rec;
    $jsonresult = json_encode($arr);
    $nbrows = $nbrows + 1;
    echo '{"results":'.$jsonresult.', "total":"'.$nbrows.'"}';
} else {
    $rec = array("0"=>"6","ID"=>"","1"=>"","countryname"=>"All Countries","2"=>"TOTAL","countrycode"=>"ALL","3"=>"5","totalbots"=>"","online"=>"");
    $arr[] = $rec;
    $jsonresult = json_encode($arr);
    echo '{"results":'.$jsonresult.', "total":0}';
}
die("");
?>