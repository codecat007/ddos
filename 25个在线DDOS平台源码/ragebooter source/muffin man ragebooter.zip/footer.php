<?php
if (!defined('DIRECT'))
{
	die('Direct access not allowed.');
}
?>
<div id="footer">
    <div class="wrapper">Copyright &copy; <?php echo date('Y')?> RAGE BOOTER</div>
</div>